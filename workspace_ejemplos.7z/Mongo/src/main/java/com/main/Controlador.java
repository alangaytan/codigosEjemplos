package com.main;

import java.text.DateFormat;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.GsonBuilder;
import com.model.Aclaracion;
import com.model.Mensaje;
import com.service.IMongoBS;

@RestController
public class Controlador {
	
	@Autowired
	private IMongoBS mongoBS;

	@RequestMapping(value = "/", method = RequestMethod.POST)
	public Mensaje insertarAclaracion(@RequestBody Aclaracion objAclaracion) {
		return mongoBS.insertarAclaracion(objAclaracion);
	}
	
	@RabbitListener(queues = "mongo")
	public void recibirMensaje(String json) {
		Aclaracion objAclaracion = new GsonBuilder().setDateFormat(DateFormat.FULL, DateFormat.FULL).create().fromJson(json, Aclaracion.class);
		mongoBS.insertarAclaracion(objAclaracion);
	}
}
