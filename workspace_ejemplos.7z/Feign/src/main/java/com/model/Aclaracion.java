package com.model;

public class Aclaracion {

	private String strId;
	private String strCategoria;
	private String strSubCategoria;
	private String strUsuario;
	
	public Aclaracion(String strCategoria, String strSubCategoria, String strUsuario) {
		this.strCategoria = strCategoria;
		this.strSubCategoria = strSubCategoria;
		this.strUsuario = strUsuario;
	};
	
	public Aclaracion() {
		this.strCategoria = "";
		this.strSubCategoria = "";
		this.strUsuario = "";
	}

	public String getStrId() {
		return strId;
	}

	public void setStrId(String strId) {
		this.strId = strId;
	}

	public String getStrCategoria() {
		return strCategoria;
	}

	public void setStrCategoria(String strCategoria) {
		this.strCategoria = strCategoria;
	}

	public String getStrSubCategoria() {
		return strSubCategoria;
	}

	public void setStrSubCategoria(String strSubCategoria) {
		this.strSubCategoria = strSubCategoria;
	}

	public String getStrUsuario() {
		return strUsuario;
	}

	public void setStrUsuario(String strUsuario) {
		this.strUsuario = strUsuario;
	};
	
}
