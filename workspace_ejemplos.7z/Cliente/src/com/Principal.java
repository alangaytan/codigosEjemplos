package com;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;

public class Principal {

	public static void main(String[] args) throws Exception {

		Transaccion objTransaccion = new Transaccion("7001390280000019", new BigDecimal(5000));
		String json = objTransaccion.toString();
		
		String urlWS = "http://localhost:8001/metodo";
		URL url = new URL(urlWS);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("strFolio", "13456789");
		connection.setDoOutput(true);
		OutputStream os = connection.getOutputStream();
		os.write(json.getBytes("UTF-8"));
		
		String respuesta = null;
		
		InputStream inputStream = (InputStream) connection.getContent();
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		BufferedReader br = new BufferedReader(inputStreamReader);
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = br.readLine()) != null) {
			sb.append(line+"\n");
		}
		br.close();
		respuesta = sb.toString();
		
		System.out.println(respuesta);
	
	}
}
