package com.service.impl;

import org.springframework.stereotype.Service;
import com.service.ITransaccionBS;

@Service
public class TransaccionBS implements ITransaccionBS{
	
	@Override
	public String holaMundo() {
		return "Hola Mundo!";
	}

}
