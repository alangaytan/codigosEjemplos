package com.service;

public interface ITransaccionBS {
	
	public String holaMundo();
}
