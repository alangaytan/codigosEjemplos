package com.main;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.Aclaracion;
import com.model.Mensaje;

@RestController
public class Controlador {
	
	@Autowired
	private RabbitTemplate rabbitTemplate;

	@RequestMapping(value = "/enviarQueue", method = RequestMethod.GET)
	public Mensaje enviarMensaje() {
		Mensaje objMensaje = new Mensaje("Operacion exitosa", "00");
		
		Aclaracion objAclaracion = new Aclaracion("rabbit", "rabbit", "rabbit");
		
		rabbitTemplate.convertAndSend("mongo", objAclaracion.toString());
		
		return objMensaje;
	}
}
