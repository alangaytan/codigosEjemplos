package com.main;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Service;

@Service
public class Procesador implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		InputStream fis = exchange.getIn().getBody(InputStream.class);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));

		String strLinea;
					
		while ((strLinea = br.readLine()) != null) {
			System.out.println(strLinea);
		}
	}

}
