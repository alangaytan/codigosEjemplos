package com.main;

import java.io.InputStream;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Controlador extends RouteBuilder {

	@Autowired
	Procesador objProcesador;
	
	@Override
	public void configure() throws Exception {
		from("ftp://desarrollo@172.20.3.121:21?password=D35arro110_T4$.&passiveMode=true&delete=true").streamCaching().convertBodyTo(InputStream.class).process(objProcesador).to("file:C:/Users/juan.gaytan/Desktop/prueba2");
	}

}
