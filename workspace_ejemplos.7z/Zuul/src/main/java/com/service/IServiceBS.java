package com.service;

import com.model.Aclaracion;
import com.model.Mensaje;

public interface IServiceBS {

	public Mensaje insertarAclaracion(Aclaracion objAclaracion);
}
