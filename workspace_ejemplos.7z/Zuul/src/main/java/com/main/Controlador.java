package com.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.Aclaracion;
import com.model.Mensaje;
import com.service.IServiceBS;

@RestController
public class Controlador {

	@Autowired
	private IServiceBS serviceBS;
	
	@RequestMapping(value = "/prueba", method = RequestMethod.GET)
	public Mensaje prueba() {
		Mensaje objMensaje = serviceBS.insertarAclaracion(
				new Aclaracion(
						"prueba categoria", 
						"prueba subcategoria", 
						"alan"
						)
				);
		return objMensaje;
	}
}
