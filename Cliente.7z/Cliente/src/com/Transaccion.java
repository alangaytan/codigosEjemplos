package com;

import java.math.BigDecimal;

public class Transaccion {

	private String strTarjeta;
	private BigDecimal bdMonto;
	
	public Transaccion(String strTarjeta, BigDecimal bdMonto) {
		this.strTarjeta = strTarjeta;
		this.bdMonto = bdMonto;
	}
	
	public Transaccion() {
		this.strTarjeta = "";
		this.bdMonto = new BigDecimal(0);
	}

	public String getStrTarjeta() {
		return strTarjeta;
	}

	public void setStrTarjeta(String strTarjeta) {
		this.strTarjeta = strTarjeta;
	}

	public BigDecimal getBdMonto() {
		return bdMonto;
	}

	public void setBdMonto(BigDecimal bdMonto) {
		this.bdMonto = bdMonto;
	}

	@Override
	public String toString() {
		return "{\"tarjeta\":\"" + strTarjeta + "\", \"bdMonto\":\"" + bdMonto + "\"}";
	}
	
	
}
