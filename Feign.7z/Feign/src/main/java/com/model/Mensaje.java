package com.model;

public class Mensaje {

	private String strDescripcion;
	private String strCodigo;
	
	public Mensaje(String strDescripcion, String strCodigo) {
		this.strDescripcion = strDescripcion;
		this.strCodigo = strCodigo;
	}
	
	public Mensaje() {
		this.strDescripcion = "";
		this.strCodigo = "";
	}

	public String getStrDescripcion() {
		return strDescripcion;
	}

	public void setStrDescripcion(String strDescripcion) {
		this.strDescripcion = strDescripcion;
	}

	public String getStrCodigo() {
		return strCodigo;
	}

	public void setStrCodigo(String strCodigo) {
		this.strCodigo = strCodigo;
	}
	
}
