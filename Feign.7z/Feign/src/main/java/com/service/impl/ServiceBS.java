package com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Aclaracion;
import com.model.Mensaje;
import com.service.IFeignBS;
import com.service.IServiceBS;

@Service
public class ServiceBS implements IServiceBS{
	
	@Autowired
	private IFeignBS feignBS;

	@Override
	public Mensaje insertarAclaracion(Aclaracion objAclaracion) {
		return feignBS.insertarAclaracion(objAclaracion);
	}

}
