package com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.IMongoDAO;
import com.model.Aclaracion;
import com.model.Mensaje;
import com.service.IMongoBS;

@Service
public class MongoBS implements IMongoBS {

	@Autowired
	private IMongoDAO mongoDAO;
	
	@Override
	public Mensaje insertarAclaracion(Aclaracion objAclaracion) {
		Mensaje objMensaje = new Mensaje("Operacion exitosa", "00");
		try {
			mongoDAO.insertarAclaracion(objAclaracion);
			System.out.println(objAclaracion.getStrId());
		} catch (Exception e) {
			e.printStackTrace();
			objMensaje = new Mensaje("Error en base de datos", "01");
		}
		return objMensaje;
	}

}
