package com.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dao.IMongoDAO;
import com.model.Aclaracion;

@Repository
public class MongoDAO implements IMongoDAO{

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Override
	public void insertarAclaracion(Aclaracion objAclaracion) {
		mongoTemplate.save(objAclaracion);
		
		objAclaracion.setStrUsuario("Alan");
		
		mongoTemplate.save(objAclaracion);
	}

}
