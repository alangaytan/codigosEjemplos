package com.dao;

import com.model.Aclaracion;

public interface IMongoDAO {

	public void insertarAclaracion(Aclaracion objAclaracion);
	
}
