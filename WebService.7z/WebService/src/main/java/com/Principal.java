package com;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Principal {

//	@Autowired
//	private ITransaccionBS transaccionBS;
	
	@RequestMapping(value = "/metodo", method = RequestMethod.POST)
	public String metodo(@RequestBody Transaccion objTransaccion){
		return "Hola tarjeta numero: " + objTransaccion.getStrTarjeta() + ", cargo de: " + objTransaccion.getBdMonto();
	}
	
	@RequestMapping(value = "/error2", method = RequestMethod.GET)
	public String error(){
		return "error!";
	}
}
